/*
题干:
1. 猎人把一对兔子婴儿(一公一母称为一对)放到一个荒岛上，两年之后，它们生下一对小兔，之后开始每年都会生下一对小兔。生下的小兔又会同样的方式继续繁殖。
2. 兔子的寿命都是x(x>=3)年，并且生命的最后一年不繁殖。
3. 如果岛上的兔子多于10对，那么猎人会每年在兔子们完成繁殖或者仙逝之后，从岛上带走两对最老的兔子。
请问y年(y>=3)后荒岛上所有的兔子加起来多少岁?(注意, 在条件3执行完之后)
 
输入: 从命令行输入两行整数，第一行是x，第二行是y
输出: y年后荒岛上所有的兔子岁数的总和

编程语言：C++，JAVA
函数名：result
时间限制： 1s   单位: 秒，C/C++最大3秒，其他语言自动增加2秒
内存限制： 1M   单位: M，C/C++最大128M，其他语言自动增加512M
返回值类型：int
函数参数：(int x,int y)
模板：
C++模板：

#include <iostream>
#include <numeric>
#include <limits>
using namespace std;
// 请完成下面这个函数，实现题目要求的功能
// 当然，你也可以不按照这个模板来作答，完全按照自己的想法来 ^-^

int result(int x, int y) {
    return 0;
}
int main() {
    int x, y;
    cin >> x;
    cin.ignore (numeric_limits<std::streamsize>::max(), '\n');
    cin >> y;
    cin.ignore (numeric_limits<std::streamsize>::max(), '\n');
    int res = result(x,y);
    cout << res << endl;
    return 0;
}

输入描述：
x //兔子的寿命
y //若干年以后

输出描述
n //所有兔子的年龄之和

输入范例：
3
3
输出范例
2

输入case01
3
5
输出
2

输入case02
5
3

输出
8

输入case03
5
5

输出
14

输入case04
4
5

输出
12

输入case05
5
7

输出
22

输入case06
6
6

输出
14

输入case07
10
10

输出
122

输入case08
5
10

输出
86

输入case09
4
10

输出
32

输入case10
5
6

输出
26
*/

#include <iostream>
#include <numeric>
#include <limits>
#include <deque>
using namespace std;
// 请完成下面这个函数，实现题目要求的功能
// 当然，你也可以不按照这个模板来作答，完全按照自己的想法来 ^-^

int result(int x, int y) {
    deque<int> q;
    q.push_back(0);
    while(y){
        --y;
        //cout<<"-->过了一年，还剩"<<y<<"年\n";
        deque<int> infants;//新生儿
        for(deque<int>::iterator it = q.begin(); it!=q.end();){
            *it = *it + 1;
            //cout<<"for循环，兔子年龄="<<*it<<"\n";
            
            if( *it >=2 ){
                if(*it==x){//到寿命了
                    //cout<<"=到寿命了\n";
                    it=q.erase(it);
                }else{//繁殖，放到队列尾部
                    infants.push_back(0);
                    //cout<<*it<<"岁的兔子繁殖\n";
                    ++it;
                }
            }else{
                //cout<<"什么也没做\n";
                ++it;
            }
            //cout<<"第一对兔子的年龄="<<*q.begin()<<endl;
        }
        //cout<<"for循环结束\n";
        for(deque<int>::iterator it =infants.begin();it!=infants.end();++it){
            q.push_back(*it);
        }
        if(q.size()>10){
            q.pop_front();//拿走2对
            q.pop_front();
            //cout<<"!!!!!拿走两对"<<endl;
        }
        //cout<<"while循环底部,q.size="<<q.size()<<"\n";
    }
    //别忘了*2
    int sum=0;
    for(deque<int>::iterator it = q.begin(); it!=q.end(); ++it){
        sum+=*it;
    }
    sum*=2;
    return sum;
}
int main() {
    int x, y;
    cin >> x;
    cin.ignore (numeric_limits<std::streamsize>::max(), '\n');
    cin >> y;
    cin.ignore (numeric_limits<std::streamsize>::max(), '\n');
    int res = result(x,y);
    cout << res << endl;
    return 0;
}
