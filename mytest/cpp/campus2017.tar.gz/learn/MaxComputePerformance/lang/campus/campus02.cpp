/*
题干：
若干个自然数(大于等于1个)是好朋友，他们手牵手坐成一个圆圈玩游戏，从第一个自然数开始报数，循环报4个数字"2,3,5,7"，第一个人报2，第二个人报3，第三个人报5，第四个人报7，第五个人报2，依次类推。
报数的同时要看自己能否被正在报的这个数字整除，如果能整除，这个报数的就出局，其他自然数继续游戏。

输入: 从命令行输入若干个整数，每行一个，第一行是自然数的的个数，后面每行一个自然数。
输出: 最后剩下的整数之和。如果最后没有任何整数剩下，请输出0

编程语言：C++，JAVA
函数名：result
时间限制： 1s   单位: 秒，C/C++最大3秒，其他语言自动增加2秒
内存限制： 1M   单位: M，C/C++最大128M，其他语言自动增加512M
返回值类型：int
函数参数：int数组，数组元素个数
模板：
C++模板：

#include <iostream>
#include <vector>
#include <numeric>
#include <limits>
using namespace std;
// 请完成下面这个函数，实现题目要求的功能
// 当然，你也可以不按照这个模板来作答，完全按照自己的想法来 ^-^
int result(const vector <int>& inputs) {
    return 0;
}

int main() {
    int size = 0;
    cin >> size;
    cin.ignore (numeric_limits<std::streamsize>::max(), '\n');
    vector<int> points;
    for(size_t i=0; i<size; ++i) {
        int item;
        cin >> item;
        cin.ignore (numeric_limits<std::streamsize>::max(), '\n');
        points.push_back(item);
    }
    int res = result(points);
    cout << res << endl;
    return 0;
}

输入描述：
n  //输入整数的个数
x1 //第一个自然数
x2  
...
xn //最后一个自然数

输入范例：
5
20
30
50
70
11
输出
11

输入case01
2
11
20

输出
31

输入case02
3
45
13
22

输出
13

输入case03
1
17

输出
17

输入case04
3
77
33
102

输出
0

输入case05
2
79
80

输出
159

输入case06
5
11
13
15
17
20

输出
41

输入case07
3
21
11
89

输出
100

输入case08
4
9
1
3
8

输出
21

输入case09
5
21
15
25
21
14

输出
0

输入case10
6
21
15
25
21
37
39

输出
58
*/

#include <iostream>
#include <vector>
#include <numeric>
#include <limits>
#include <set>
using namespace std;
// 请完成下面这个函数，实现题目要求的功能
// 当然，你也可以不按照这个模板来作答，完全按照自己的想法来 ^-^

int divisor[]={2,3,5,7};
const size_t len=sizeof(divisor)/sizeof(divisor[0]);
int gcd(int a,int b){//greatest common divisor
    int s1=a>b? a:b;
    int s2=a>b? b:a;
    while(s2!=0){
        int tmp=s2;
        s2=s1%s2;//余数
        s1=tmp;
    }
    return s1;
}
int lcm(int a,int b){
    return a*b/gcd(a,b);
}
void printVector(const vector<int>& inputs){
    cout<<"打印vector:";
    for(size_t i=0;i<inputs.size();++i){
        cout<<inputs[i]<<',';
    }
    cout<<endl;
}
int result(vector<int>& inputs) {
    size_t fromLastChange = 0;//距离上一次剔除数字过去了多少步
    size_t index = 0; // divisor数组下标
    int lcm_n = lcm(inputs.size(), len);
    
    for(vector<int>::iterator it = inputs.begin();;){//无限循环
        //printVector(inputs);
        //cout<<"考察"<<*it<<"%"<<divisor[index]<<endl;
        if(*it % divisor[index] == 0){//整除
            //cout << *it << "出局" << endl;
            it = inputs.erase(it);//更新迭代器
            fromLastChange = 0;   //重新开始计数
            lcm_n = lcm(inputs.size(), len);
        }else{
            ++it;
        }
        if(it==inputs.end()){
            it=inputs.begin();
        }
        if(inputs.empty()){//已经没有任何元素了
            return 0;
        }

        //还有元素
        ++fromLastChange;
        if(fromLastChange >= lcm_n){
            //已经一轮没有任何变化了，游戏结束
            //cout<<"游戏结束"<<endl;
            int sum = 0;
            for(size_t i=0;i<inputs.size();++i){
                sum+=inputs[i];
            }
            return sum;
        }
        index = (index+1)%len;//循环报数
    }
    return 0;
}
int main() {
    int size = 0;
    cin >> size;
    cin.ignore (numeric_limits<std::streamsize>::max(), '\n');
    vector<int> points;
    for(size_t i=0; i<size; ++i) {
        int item;
        cin >> item;
        cin.ignore (numeric_limits<std::streamsize>::max(), '\n');
        points.push_back(item);
    }
    int res = result(points);
    cout << res << endl;
    //cout << gcd(12,2) << endl;
    //cout << lcm(27,12) << endl;
    return 0;
}
