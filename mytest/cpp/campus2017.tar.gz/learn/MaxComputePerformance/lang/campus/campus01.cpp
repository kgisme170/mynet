/*
题干：
1. 从命令行输入若干个正整数(大于等于2个)，得到一个集合N。
2. 从N中任意取出两个数并求和，得到的值构成集合A。
3. 从N中任意取出两个数，并求差的绝对值，得到的值构成集合B。
4. 从集合A和集合B当中，任意取出两个数，其差的绝对值，又构成集合D
D的最小元素是d1,D的最大元素是d2,D的元素个数是s
请输出d1+d2+s

编程语言：C++，JAVA
函数名：result
时间限制： 1s   单位: 秒，C/C++最大3秒，其他语言自动增加2秒
内存限制： 1M   单位: M，C/C++最大128M，其他语言自动增加512M
返回值类型：int
函数参数：int数组，数组元素个数
模板：
C++模板：

#include <iostream>
#include <vector>
#include <numeric>
#include <limits>
using namespace std;
// 请完成下面这个函数，实现题目要求的功能
// 当然，你也可以不按照这个模板来作答，完全按照自己的想法来 ^-^
int result(const vector <int>& inputs) {
    return 0;
}

int main() {
    int size = 0;
    cin >> size;
    cin.ignore (numeric_limits<std::streamsize>::max(), '\n');
    vector<int> points;
    for(size_t i=0; i<size; ++i) {
        int item;
        cin >> item;
        cin.ignore (numeric_limits<std::streamsize>::max(), '\n');
        points.push_back(item);
    }
    int res = result(points);
    cout << res << endl;
    return 0;
}

输入描述：
输入整数的个数n
x1
x2  
...
xn 

输入范例：
5
1
1
1
1
1
输出
5

输入case01:
5
1
1
2
3
4

输出
15

输入case02:
4
1
1
2
3

输出
11

输入case03:
2
10
20

输出
41

输入case04:
6
7
7
8
8
9
9

输出
37

输入case05:
6
100
200
300
1
2
3

输出
555

输入case06:
6
3
4
12
11
26
27

输出
85

输入case07:
3
19
40
41

输出
124

输入case08:
10
5
6
6
7
7
7
8
8
8
8

输出
33

输入case09:
7
19
20
21
9
10
11
1

输出
75

输入case10:
8
8
18
28
38
4
14
6
16

输出
97

*/
#include <iostream>
#include <vector>
#include <numeric>
#include <limits>
#include <set>
using namespace std;
// 请完成下面这个函数，实现题目要求的功能
// 当然，你也可以不按照这个模板来作答，完全按照自己的想法来 ^-^
int result(const vector <int>& inputs) {
    //构造集合A和B
    vector<int> A,B;
    for(size_t i=0;i<inputs.size();++i){
        for(size_t j=i+1;j<inputs.size();++j){
            int sum=inputs[i]+inputs[j];
            int delta=abs(inputs[i]-inputs[j]);
            A.push_back(sum);
            B.push_back(delta);
        }
    }
    set<int> s;
    for(size_t i=0;i<A.size();++i){
        for(size_t j=0;j<A.size();++j){
            int dist=abs(A[i]-B[j]);
            s.insert(dist);
        }
    }
    //cout<<endl;
    vector<int> distance;
    for(set<int>::iterator it=s.begin();it!=s.end();++it){
        distance.push_back(*it);
        //cout<<*it<<',';
    }
    //cout<<endl;
    return distance[0]+distance[distance.size()-1]+s.size();
}

int main() {
    int size = 0;
    cin >> size;
    cin.ignore (numeric_limits<std::streamsize>::max(), '\n');
    vector<int> points;
    for(size_t i=0; i<size; ++i) {
        int item;
        cin >> item;
        cin.ignore (numeric_limits<std::streamsize>::max(), '\n');
        points.push_back(item);
    }
    int res = result(points);
    cout << res << endl;
    return 0;
}
